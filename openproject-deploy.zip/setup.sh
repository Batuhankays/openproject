#!/bin/bash
set -e

echo "🚀 Starting OpenProject Deployment on $(hostname)..."

# 1. Update and Install Docker if missing
if ! command -v docker &> /dev/null; then
    echo "📦 Installing Docker..."
    curl -fsSL https://get.docker.com | sh
    sudo usermod -aG docker $USER
    echo "⚠️  User added to docker group. You might need to re-login. Proceeding with sudo..."
fi

# 2. Check for Docker Compose
if ! command -v docker-compose &> /dev/null; then
    echo "📦 Installing Docker Compose..."
    sudo apt-get update && sudo apt-get install -y docker-compose-plugin
    # Fallback alias if needed
    alias docker-compose='docker compose'
fi

# 3. Stop existing containers
echo "🛑 Stopping existing containers..."
docker compose down || true

# 4. Build and Start
echo "🏗️  Building and Starting OpenProject Enterprise..."
docker compose up -d --build

# 5. Wait for Database
echo "⏳ Waiting for Database to be ready (30s)..."
sleep 30

# 6. Restore Database (Template Data)
if [ -f "openproject.sql" ]; then
    echo "♻️  Restoring Database (Templates, Boards, Users)..."
    # Drop existing connections/db to ensure clean restore or just copy over?
    # pg_dump usually includes CREATE, but we have an initialized DB.
    # We will drop the public schema and restore.
    
    docker exec -i openproject-db-enterprise psql -U postgres -c "DROP SCHEMA public CASCADE; CREATE SCHEMA public;" openproject
    
    cat openproject.sql | docker exec -i openproject-db-enterprise psql -U postgres openproject
    
    echo "✅ Database restore complete."
else
    echo "⚠️  openproject.sql not found! Skipping restore."
fi

# 7. Restart to apply changes
echo "🔄 Restarting application..."
docker compose restart

echo "✅ Deployment Finished!"
echo "🌍 Access OpenProject at http://$(hostname -I | awk '{print $1}'):8200"
echo "🔑 Admin password is the same as your local setup (or 'admin' if reset)"
